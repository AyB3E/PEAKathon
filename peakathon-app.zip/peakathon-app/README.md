# PEAKathon Case Evaluator — Hosted Deploy Guide

An agentic AI proof-of-concept for P&G India's Talent Practice. It reads a candidate's
case-round PDF and scores it against the P&G way of problem-solving across six weighted
dimensions, with evidence, then routes borderline cases to a human.

This folder is **deploy-ready for Vercel** (free tier). You get a public link you can send to anyone.

---

## What's in here

```
peakathon-app/
├── public/index.html      ← the whole front-end (UI + baked-in samples)
├── api/evaluate.js         ← serverless function: holds your API key, calls Claude
├── vercel.json             ← routing config
├── package.json
└── README.md               ← this file
```

The browser never sees your API key. The front-end calls `/api/evaluate`, and that
function — running on Vercel's server — adds the secret key and forwards the PDF to Claude.

---

## Deploy in ~5 minutes (no coding)

### What you need first
1. A **free Vercel account** → https://vercel.com/signup (sign up with GitHub, GitLab, or email).
2. An **Anthropic API key** → https://console.anthropic.com → "API Keys" → "Create Key".
   Copy it somewhere safe; you'll paste it into Vercel, not into any file.

### Option A — Drag-and-drop (simplest)
1. Install the Vercel CLI once: open a terminal and run `npm i -g vercel`.
2. In the terminal, `cd` into this `peakathon-app` folder.
3. Run `vercel`. Log in when prompted, accept the defaults (it auto-detects the setup).
4. When it finishes it prints a URL like `https://peakathon-app-xxxx.vercel.app`.
5. **Add your key as a secret** (this is the important step):
   `vercel env add ANTHROPIC_API_KEY`
   Paste your key, choose **Production** (and Preview/Development if asked).
6. Redeploy so the key takes effect: `vercel --prod`.
7. Open the printed URL. Live scoring now works. Done — share that link.

### Option B — Through the Vercel website (no terminal)
1. Put this `peakathon-app` folder into a GitHub repo (GitHub Desktop works if you don't use git).
2. On vercel.com → "Add New… → Project" → import that repo.
3. Framework preset: **Other**. Output directory: **public**. Click Deploy.
4. After it deploys: Project → **Settings → Environment Variables** → add
   `ANTHROPIC_API_KEY` = your key (scope: Production). Save.
5. Deployments tab → **Redeploy** the latest.
6. Open the live URL. Share it.

---

## Using it live

- **Real submission:** drag a candidate's PDF onto the box → "Evaluate submission". The agent reads it and scores in ~10-20 seconds.
- **Stage-safe demo:** the three "pre-scored sample" buttons (Strong / Borderline / Weak) render full evaluations instantly, no network needed. Use these if the wifi is shaky. **Tip for presenting:** lead with the *Borderline* sample — it shows the agent declining to auto-decide and handing off to a human, which is the point that lands with an HR audience.

---

## Cost & safety notes

- Each live evaluation is one Claude API call on a PDF — cents, not dollars. Set a spend limit
  in the Anthropic console (Billing → Usage limits) so a shared link can't run up a surprise bill.
- The key lives only in Vercel's encrypted env vars. It is never in the HTML, never in the repo,
  never sent to the browser. If you ever suspect it leaked, rotate it in the Anthropic console.
- This is a POC of the evaluation layer. Before any real shortlisting: calibrate the agent's scores
  against past human-graded PEAKathon decks, bias-audit across cohorts, and keep a human as the
  decision-maker. The ±0.25 review band is the built-in safety rail, not a substitute for that work.

---

## Changing the model or rubric

- **Model:** `api/evaluate.js`, the `model` field. Currently `claude-sonnet-4-6` (verified current, May 2026).
- **Rubric / weights:** `public/index.html`, the `DIMENSIONS` array near the top of the script.
  Weights must sum to 1.0. Structure is intentionally the lowest at 10%.
- **Shortlist bar / review band:** same file, `SHORTLIST_THRESHOLD` and `REVIEW_BAND`.
